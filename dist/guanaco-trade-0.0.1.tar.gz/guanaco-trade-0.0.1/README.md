# guanaco
#### <span style="color:gray">The AI stock trading interface</span>


### How to use
Check out example.py :D


<span style="color:DimGray">better readme coming soon</span>